"""Command-line interface for YouTube thumbnail downloader."""
import sys
import os
from youtube_thumb import download_thumbnail, YouTubeURLError, DownloadError, InvalidPathError

def main():
    """Main entry point for the command-line interface."""
    # Check arguments
    if len(sys.argv) != 3:
        print("Usage: python main.py <youtube_url> <download_path>")
        sys.exit(1)
        
    url = sys.argv[1]
    download_path = sys.argv[2]
    
    try:
        # Download thumbnail
        saved_path = download_thumbnail(url, download_path)
        print(f"Successfully downloaded thumbnail to: {saved_path}")
        
    except YouTubeURLError as e:
        print(f"Error: Invalid YouTube URL - {str(e)}")
        sys.exit(1)
    except DownloadError as e:
        print(f"Error: Download failed - {str(e)}")
        sys.exit(1)
    except InvalidPathError as e:
        print(f"Error: Invalid download path - {str(e)}")
        sys.exit(1)
    except Exception as e:
        print(f"Error: An unexpected error occurred - {str(e)}")
        sys.exit(1)

if __name__ == "__main__":
    main()
