"""Main functionality for downloading YouTube thumbnails."""
import os
from urllib.request import urlopen, Request
from urllib.error import URLError
from typing import Optional

from .exceptions import YouTubeURLError, DownloadError, InvalidPathError
from .utils import extract_video_id, get_thumbnail_url

def download_thumbnail(url: str, download_path: str) -> str:
    """
    Download a YouTube video thumbnail.
    
    Args:
        url: The YouTube video URL
        download_path: The path where the thumbnail should be saved
        
    Returns:
        The path to the downloaded thumbnail
        
    Raises:
        YouTubeURLError: If the URL is invalid or video ID cannot be extracted
        DownloadError: If the thumbnail cannot be downloaded
        InvalidPathError: If the download path is invalid or inaccessible
    """
    # Extract video ID
    video_id = extract_video_id(url)
    if not video_id:
        raise YouTubeURLError(f"Could not extract video ID from URL: {url}")
    
    # Validate download path
    try:
        download_dir = os.path.dirname(download_path)
        if download_dir and not os.path.exists(download_dir):
            os.makedirs(download_dir)
    except OSError as e:
        raise InvalidPathError(f"Invalid download path: {download_path}") from e
    
    # Construct thumbnail URL
    thumbnail_url = get_thumbnail_url(video_id)
    
    # Download thumbnail
    try:
        # Add User-Agent header to avoid potential 403 errors
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
        req = Request(thumbnail_url, headers=headers)
        
        with urlopen(req) as response, open(download_path, 'wb') as out_file:
            out_file.write(response.read())
            
        return download_path
            
    except URLError as e:
        raise DownloadError(f"Failed to download thumbnail: {str(e)}") from e
    except OSError as e:
        raise DownloadError(f"Failed to save thumbnail: {str(e)}") from e
