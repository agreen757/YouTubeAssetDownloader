"""Custom exceptions for the YouTube thumbnail downloader."""

class YouTubeURLError(Exception):
    """Raised when the YouTube URL is invalid or cannot be parsed."""
    pass

class DownloadError(Exception):
    """Raised when the thumbnail cannot be downloaded."""
    pass

class InvalidPathError(Exception):
    """Raised when the download path is invalid or inaccessible."""
    pass
