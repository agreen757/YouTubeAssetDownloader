"""YouTube Thumbnail Downloader Package."""
from .downloader import download_thumbnail
from .exceptions import (
    YouTubeURLError,
    DownloadError,
    InvalidPathError
)

__version__ = "1.0.0"
__all__ = ['download_thumbnail', 'YouTubeURLError', 'DownloadError', 'InvalidPathError']
