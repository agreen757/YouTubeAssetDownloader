"""Utility functions for YouTube thumbnail downloader."""
import re
from urllib.parse import urlparse, parse_qs
from typing import Optional

def extract_video_id(url: str) -> Optional[str]:
    """
    Extract the video ID from various YouTube URL formats.
    
    Supported formats:
    - https://youtube.com/watch?v=VIDEO_ID
    - https://youtu.be/VIDEO_ID
    - https://youtube.com/shorts/VIDEO_ID
    - https://youtube.com/embed/VIDEO_ID
    
    Args:
        url: The YouTube video URL
        
    Returns:
        The video ID if found, None otherwise
    """
    # Regular expression patterns for different URL formats
    patterns = [
        r'(?:v=|\/)([0-9A-Za-z_-]{11}).*',
        r'(?:youtu\.be\/)([0-9A-Za-z_-]{11})',
        r'(?:shorts\/)([0-9A-Za-z_-]{11})',
        r'(?:embed\/)([0-9A-Za-z_-]{11})'
    ]
    
    # Try parsing URL parameters first
    parsed_url = urlparse(url)
    if 'youtube.com' in parsed_url.netloc:
        query_params = parse_qs(parsed_url.query)
        if 'v' in query_params:
            return query_params['v'][0]
    
    # Try matching patterns
    for pattern in patterns:
        match = re.search(pattern, url)
        if match:
            return match.group(1)
            
    return None

def get_thumbnail_url(video_id: str) -> str:
    """
    Construct the thumbnail URL from the video ID.
    
    Args:
        video_id: The YouTube video ID
        
    Returns:
        The URL of the highest quality thumbnail
    """
    return f"https://img.youtube.com/vi/{video_id}/maxresdefault.jpg"
